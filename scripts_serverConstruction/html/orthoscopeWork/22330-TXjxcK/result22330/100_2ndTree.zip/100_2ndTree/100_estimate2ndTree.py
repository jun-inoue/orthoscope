#!/usr/bin/env python
# coding: utf-8

import re, os
from collections import OrderedDict
import subprocess


#########################################

dataset = "Exc3rd"
#dataset = "Inc3rd"
#dataset = "prot"

num_pthred_raxml = 2 # 2
#treeSearchMethod = "NJ"
treeSearchMethod = "NJ"
## NJ method cannot be used for prot alignments in this script.

## 20190109 Jun Inoue
#########################################

geneticCode = {
           #"((U|T|C|Y|A)(U|T)G)"               : "B",
           #"((C(U|T).)|((U|T)(U|T)(A|G|R)))"   : "L",
            "CTA"                             : "L",
            "CTT"                             : "L",
            "CTG"                             : "L",
            "CTC"                             : "L",
            "TTA"                             : "L",
            "TTG"                             : "L",
            "TTR"                             : "L",
           # "((CG.)|(AG(A|G|R)))"               : "R",
            "CGA"                             : "R",
            "CGT"                             : "R",
            "CGG"                             : "R",
            "CGC"                             : "R",
            "AGA"                             : "R",
            "AGG"                             : "R",
            "AGR"                             : "R",
           # "(((U|T)C.)|(AG(U|T|C|Y)))"         : "S",
            "TCA"                             : "S",
            "TCT"                             : "S",
            "TCG"                             : "S",
            "TCC"                             : "S",
            "AGT"                             : "S",
            "AGC"                             : "S",
            "AGY"                             : "S",
           # "(GC.)"                             : "A",
            "GCA"                             : "A",
            "GCT"                             : "A",
            "GCG"                             : "A",
            "GCC"                             : "A",
           # "(GG.)"                             : "G",
            "GGT"                             : "G",
            "GGC"                             : "G",
            "GGA"                             : "G",
            "GGG"                             : "G",
           # "(CC.)"                             : "P",
            "CCT"                             : "P",
            "CCC"                             : "P",
            "CCA"                             : "P",
            "CCG"                             : "P",
           # "(AC.)"                             : "T",
            "ACT"                             : "T",
            "ACC"                             : "T",
            "ACA"                             : "T",
            "ACG"                             : "T",
           # "(G(U|T).)"                         : "V",
            "GTT"                             : "V",
            "GTC"                             : "V",
            "GTA"                             : "V",
            "GTG"                             : "V",
           # "(A(U|T)(U|T|C|Y|A))"               : "I",
            "ATT"                             : "I",
            "ATC"                             : "I",
            "ATA"                             : "I",
           # "(((U|T)A(A|G|R))|((T|U)GA))"    : "_",
            "TAA"                             : "X",  #* Ter
            "TAG"                             : "X",  #* Ter
            "TAR"                             : "X",  #* Ter
            "TGA"                             : "X",  #* Ter
           # "((U|T)G(U|T|C|Y))"                 : "C",
            "TGT"                             : "C",  #Cys  
            "TGC"                             : "C",  #Cys  
            "TGY"                             : "C",  #Cys  
           # "(GA(U|T|C|Y))"                     : "D",
            "GAT"                             : "D",  #Asp
            "GAC"                             : "D",  #Asp
            "GAY"                             : "D",  #Asp
           # "(GA(A|G|R))"                       : "E",
            "GAA"                             : "E",  #Glu
            "GAG"                             : "E",  #Glu
            "GAR"                             : "E",  #Glu
           # "((U|T)(U|T)(U|T|C|Y))"             : "F",
            "TTT"                             : "F",  #Phe
            "TTC"                             : "F",  #Phe
            "TTY"                             : "F",  #Phe
           # "(CA(U|T|C|Y))"                     : "H",
            "CAT"                             : "H",  #His
            "CAC"                             : "H",  #His
            "CAY"                             : "H",  #His
           # "(AA(A|G|R))"                       : "K",
            "AAA"                             : "K",  #Lys
            "AAG"                             : "K",  #Lys
            "AAR"                             : "K",  #Lys
           # "(AA(U|T|C|Y))"                     : "N",
            "AAT"                             : "N",  #Asn
            "AAC"                             : "N",  #Asn
            "AAY"                             : "N",  #Asn
           # "(CA(A|G|R))"                       : "Q",
            "CAA"                             : "Q",  #Gln
            "CAG"                             : "Q",  #Gln
            "CAR"                             : "Q",  #Gln
           # "((U|T)A(U|T|C|Y))"                 : "Y",
            "TAT"                             : "Y",  #Tyr
            "TAC"                             : "Y",  #Tyr
            "TAY"                             : "Y",  #Tyr
           # "(A(U|T)G)"                         : "M",
            "ATG"                             : "M",  #Met
           # "((U|T)GG)"                         : "W",
            "TGG"                             : "W",  #Trp  
           # "..."                               : "X",
           # "(NNN)"                             : "X",
            "NNN"                             : "X",  
           # "(N(.|N).)"                         : "X",
            "N.."                             : "X",  
            "NN."                             : "X",  
           # "(.(.|N)N)"                         : "X",
            ".NN"                             : "X",  
            "..N"                             : "X",  
           # "(.N.)"                             : "X",
            ".N."                             : "X",  
            "---"                             : "-"}
### Codes follow pal2nal.



### Functions
def readFasta_dict(InfileNameFN):
    Infile = open(InfileNameFN, "r")
    seqDictFN  = OrderedDict()
    for Line in Infile:
        #print(Line)
        Line = Line.rstrip("\n")
        if not Line:
            continue
        elif Line[0] == ">":
            Name            = Line
            seqDictFN[Name] = ""
        else:
            Line = Line.replace("\n", "")
            Line = Line.replace("\r", "")
            seqDictFN[Name] += Line.upper()
    Infile.close()
    return seqDictFN
    
def readPhy_dict(phyFileName):
    phyFile = open(phyFileName, "r")
    lines = list(phyFile)
    seqDictFN  = OrderedDict()
    for line in lines[1:]:
        #print("line:", line)
        name,seq = re.split(" +", line)
        #print("seq:", seq) 
        seq = seq.rstrip("\n")
        seqDictFN[">" + name] = seq
    phyFile.close()
    return seqDictFN

def splitDna(dna):
    codons = []
    for start in range(0, len(dna)-2, 3):
        codons.append(dna[start:start+3])
    return(codons)

def translation(dna):
    dna = dna.upper()
    protein = ""
    for codon in splitDna(dna):
        aaChr = geneticCode.get(codon, "X")
        protein = protein + aaChr
    return protein

def read_summary(summaryFile):
    f = open(summaryFile, "r")
    InfileLines = list(f)
    sumDictFN  = OrderedDict()
    for Line in InfileLines:
        #print(Line)
        Line = Line.rstrip("\n")
        if not Line:
            continue
        if Line[0] == "#":
            continue
        if Line[0] == ">":
            Name            = Line
            sumDictFN[Name] = ""
        else:
            sumDictFN[Name] += Line + "|"
    return sumDictFN
    
    
def seqCounter(summaryFile, cDNAfasFileName, outfile):
    recsFN = readFasta_dict(cDNAfasFileName)
    summaryFN = read_summary(summaryFile)

    names_analyzed_TMP = summaryFN[">taxonSampling_color"].split("|")
    names_analyzed  = OrderedDict()
    for nameLine in names_analyzed_TMP:
        if len(nameLine) < 1:
            break
        match = re.search("^([^ ]+)_+([^ ]+)$", nameLine)
        name = match.group(1)
        color = match.group(2)
        names_analyzed[">" + name] = 0
    names_analyzed = whiteSpaceAdd(names_analyzed)

    out = open(outfile, "w")
    out.write(">Num_gene\n")
    for name_with_whites in names_analyzed:
        count = 0
        name_without_whites = re.sub(" +.*", "", name_with_whites)
        for name_seq in recsFN.keys():
            if name_without_whites in name_seq:
                count = count + 1
        out.write(name_with_whites + str(count) + "\n")
    out.write("\n")

    out.write(">Length_gene\n")
    recsFN = whiteSpaceAdd(recsFN)
    for name_with_whites in names_analyzed:
        name_without_whites = re.sub(" +.*", "", name_with_whites)
        flag = 0
        for name_rec, seq_rec in recsFN.items():
            if name_without_whites in name_rec:
                out.write(name_rec + str(len(seq_rec)) + "\n")
                flag = 1
        if flag == 0:
            out.write(name_with_whites + "######## No gene ########\n")
    out.close()


def cDNAfas2noGapAAFasFile(cDNAfasFileName):
    recsFN = readFasta_dict(cDNAfasFileName)
    recsFN = delete_gap(recsFN)
    fa = open("110_noGapAA.txt","w")
    for name, seq in recsFN.items():
        fa.write(name + "\n")
        if dataset == "prot":
            fa.write(seq + "\n")
        else:
            fa.write(translation(seq) + "\n")
    fa.close()

def delete_gap(recsFN):
    recsFN1        = OrderedDict()
    for name, seq in recsFN.items():
        seq = re.sub("-", "", seq)
        recsFN1[name] = seq
    return recsFN1

def fas2noGapfasFile(fasFileName):
    recsFN = readFasta_dict(fasFileName)
    recsFN = delete_gap(recsFN)
    fa = open("110_noGapCDNA.txt","w")
    for name, seq in recsFN.items():
        fa.write(name + "\n")
        fa.write(seq  + "\n")
    fa.close()

def orderedDict2phyFile(recs, outfile):
    secLength     = len(sorted(recs.values())[0])
    spSeqSizeLine = str(len(recs)) + " " + str(secLength)

    recs = whiteSpaceAdd(recs)
    out  = open(outfile, "w")
    out.write(spSeqSizeLine + "\n")
    for name,value in recs.items():
        out.write(name + value + "\n")
    out.close()
    
def trimalResCounter(firstRecName_asReference, trimAAresult):
    f = open(trimAAresult)
    Lines = list(f)
    f.close()
    lineModified = ""
    for line in Lines:
        if line.startswith("    <span class=sel>" + firstRecName_asReference):
            line = line.rstrip("\n")
            line = re.sub("<span class=sel>" + firstRecName_asReference + "</span>", "", line)
            #print(line)
            #line = re.sub("<span id=.>.</span>", "#", line)
            line = re.sub("<span class=[^>]+>.</span>", "#", line)
            #print(line)
            #exit()
            line = re.sub(" ", "", line)
            lineModified += line
    return lineModified

def whiteSpaceAdd(recsFN1):
    longestName = max(recsFN1.keys(), key = len)
    longestName = re.sub("<[^>]+>", "", longestName)
    longestNameLen = len(longestName)
    recsFN2        = OrderedDict()
    for name,value in recsFN1.items():
        nameTMP = re.sub("<[^>]+>", "", name)
        nameWhiteSpace = name[1:] + " " * (longestNameLen - len(nameTMP) + 2)
        recsFN2[nameWhiteSpace] = value
    return recsFN2
    
def trimaledCDNAphyMake(fastaFile, trimAAresult):
    recs = readFasta_dict(fastaFile)
    firstRecName_asReference = list(recs.keys())[0]
    trimalMarkedSites = trimalResCounter(firstRecName_asReference[1:], trimAAresult)

    recsTrimed = OrderedDict()
    for name,value in recs.items():
        sequence = ""
        for i in range(len(trimalMarkedSites)):
            if trimalMarkedSites[i] == "#":
                #out.write(trimalMarkedSites[i])
                sequence += value[i*3] + value[i*3+1] + value[i*3+2]
        recsTrimed[name] = sequence
    orderedDict2phyFile(recsTrimed, outfile = "150_trimedCDNAPhy.txt")

def codonSepalate(recs):
    recs1 = OrderedDict()
    recs2 = OrderedDict()
    recs3 = OrderedDict()
    for name, sec in recs.items():
        recs1[name] = ""
        recs2[name] = ""
        recs3[name] = ""
        for i in range(len(sec)):
            if   i%3 == 0:
               recs1[name] += sec[i]
            elif i%3 == 1:
               recs2[name] += sec[i]
            else:
               recs3[name] += sec[i]
    return recs1, recs2, recs3

def phyCodonToBlock(phyFileName, dataset, outfile):
    recs = readPhy_dict(phyFileName)
    recs1, recs2, recs3 = codonSepalate(recs)
    recsS1 = OrderedDict()
    if dataset == "Include3rd":
        for name in recs1.keys():
            recsS1[name] = recs1[name] + recs2[name] + recs3[name]
            
    if dataset == "Exclude3rd":
        for name in recs1.keys():
            recsS1[name] = recs1[name] + recs2[name]

    recsS2 = whiteSpaceAdd(recsS1)

    out = open(outfile, "w")
    out.write(str(len(recsS2)) + " " + str(len(list(recsS2.values())[0])) + "\n")
    for name,sec in recsS2.items():
        out.write(name + sec + "\n")
    out.close()

def delete_nameSpaceSeqBp(recsFN):
    recsFN2        = OrderedDict()
    for name, seq in recsFN.items():
        if re.search(" \d+ bp$", name):
            name = re.sub(" \d+ bp$", "", name)
        recsFN2[name] = seq
    return recsFN2

def fas2phy(fasFileName, outfile):
    recsFN = readFasta_dict(fasFileName)
    recsFN = delete_nameSpaceSeqBp(recsFN)
    orderedDict2phyFile(recsFN, outfile)

def raxmlInfileMake():
    phyFile = open("160_trimedBlockInc3rdPhy.txt", "r")
    phyLines = list(phyFile)
    phyFile.close() 
    spNumTMP, seqLength = re.split(" ",  phyLines[0])
    outGroup, seqTMP    = re.split(" +", phyLines[1])

    #comFile = open("170_raxmlCommand.txt", "w")
    #comFile.write("raxmlHPC-PTHREADS-SSE3 -f a -x 12345 -p 12345 -# 100 -m GTRGAMMA -s 160_trimedBlockInc3rdPhy.txt -q 170_raxmlPartition.txt -o " + outGroup + " -n Inc3rd.txt -T 2\n")
    #comFile.write("raxmlHPC-PTHREADS-SSE3 -f a -x 12345 -p 12345 -# 100 -m PROTGAMMAWAGF -s 150_trimedAAPhy.txt -o " + outGroup + " -n AA.txt -T 2\n")
    #comFile.close()

    seqLength = int(seqLength)
    partFile = open("170_raxmlPartition.txt", "w")
    partFile.write("DNA,gene1=1-"                                    + str(int(seqLength/3)) + "\n")
    partFile.write("DNA,gene2=" + str(int(seqLength/3)     + 1)     + "-" + str((int(seqLength/3))*2)   + "\n")
    if dataset == "Inc3rd":
        partFile.write("DNA,gene3=" + str((int(seqLength/3))*2 + 1)     + "-" + str(seqLength)   + "\n")
    partFile.close()

def outGroupSelect (phyFileName):
    recSeqFN = readPhy_dict(phyFileName)
    outgroupTMP = list(recSeqFN.keys())[0]
    return outgroupTMP[1:]


### Tree file Start
def nhx2NewickWithNHXnodeName(tree):
  
    cladeReg = "\)([^\[]+\[&&NHX[^\]]+\])"
    count = 0
    while re.search(cladeReg, tree):
        #print("count   :", count)
        matchA = re.search(cladeReg, tree)
        expTemp  = matchA.group(1);
        #print("expTemp:", expTemp)
        #if count == 10:
        #    exit()

        matchB = re.search("(\[.*\])", expTemp)
        exp  = matchB.group(1)
 
        if re.search("B=([\d]+)", expTemp):
            matchC = re.search("B=([\d]+)", expTemp)
            bs = matchC.group(1)
        else:
            bs = "r"

        exp = re.sub("&&NHX:", "", exp)
        exp = re.sub(":",      "_", exp)
        exp = re.sub("_B=.*$", "", exp)
        
        #print("expTemp :", expTemp)
        #print("bs      :", bs)
        #print("exp     :", exp)
        #print("bs + exp:", bs + exp)

        tree = re.sub(cladeReg, ")" + bs + "_" + exp, tree, 1)
        count += 1
        #print("tree2: ", tree)
        #print()
    
    tree = re.sub("\:[\d|\.E-]+", "", tree)   #Delete the branch lengths

    ## left node name
    tree = re.sub("\[&&NHX:[^]]+\]", "",  tree)
    tree = re.sub("[\[\]]",          "", tree)
    #tree = re.sub("\]",              "",  tree)

    return tree;
### Tree file End


### Blast Start
def remove_files1():
    subprocess.call("rm RAxML_*", shell=True)

def remove_files2():
    subprocess.call("rm 110_*", shell=True)
    subprocess.call("rm 120_mafOut.txt", shell=True)
    subprocess.call("rm 130_trimedAAOutFas.txt", shell=True)
    subprocess.call("rm 140_aln_nucl_fas.txt", shell=True)
    subprocess.call("rm 150_*", shell=True)
    subprocess.call("rm 160_*", shell=True)
    subprocess.call("rm 170_*", shell=True)


######################################################################################################################
#################################### Main program ####################################################################
######################################################################################################################


'''
'''

#remove_files1()

alignmentFile = ""
if dataset == "prot":
    alignmentFile = "010_candidates_prot.txt"
else:
    alignmentFile = "010_candidates_nucl.txt"

seqCounter(summaryFile = "../000_summary.txt", cDNAfasFileName = "../" + alignmentFile, outfile = "200_num_genes.txt")

cDNAfas2noGapAAFasFile("../" + alignmentFile)

if dataset != "prot":
    fas2noGapfasFile("../" + alignmentFile)

maffLine1 = "mafft 110_noGapAA.txt > 120_mafOut.txt"
##print("maffLine1", maffLine1)
subprocess.call(maffLine1, shell=True)


trimLine1 = "trimal -out 130_trimedAAOutFas.txt -htmlout 200_aln_prot.html -in 120_mafOut.txt -gappyout"
###print("trimLine1:", trimLine1, "\n");
subprocess.call(trimLine1, shell=True)

if dataset != "prot":
    pal2nalLine = "pal2nal.pl 120_mafOut.txt 110_noGapCDNA.txt -output fasta > 140_aln_nucl_fas.txt"
    ###print (pal2nalLine)
    subprocess.call(pal2nalLine, shell=True)

fas2phy("120_mafOut.txt", outfile="200_aln_prot.txt")
fas2phy("130_trimedAAOutFas.txt", outfile="150_trimedAAPhy.txt")
if dataset != "prot":
    fas2phy("140_aln_nucl_fas.txt", outfile="200_aln_nucl.txt")
    trimaledCDNAphyMake("140_aln_nucl_fas.txt", "200_aln_prot.html")

    phyCodonToBlock("150_trimedCDNAPhy.txt", "Exclude3rd", outfile="160_trimedBlockExc3rdPhy.txt")
    phyCodonToBlock("150_trimedCDNAPhy.txt", "Include3rd", outfile="160_trimedBlockInc3rdPhy.txt")


if dataset != "prot":
    raxmlInfileMake()
outputTree = ""
if treeSearchMethod == "NJ":
    if dataset == "Exc3rd":
        outGroup = outGroupSelect("160_trimedBlockExc3rdPhy.txt")
        treeEstimationLine = "Rscript 104_NJBSa.R 160_trimedBlockExc3rdPhy.txt " + outGroup + " TN93 200_NJBStree.txt"
        outputTree = "200_NJTree_Exc3rd.pdf"
    elif dataset == "Inc3rd":
        outGroup = outGroupSelect("160_trimedBlockInc3rdPhy.txt")
        outGroup = outGroupSelect("160_trimedBlockExc3rdPhy.txt")
        treeEstimationLine = "Rscript 104_NJBSa.R 160_trimedBlockInc3rdPhy.txt " + outGroup + " TN93 200_NJBStree.txt"
        outputTree = "200_NJTree_Inc3rd.pdf"
    else:
        print("Cannot estimate NJ tree with amino acid data.\n")
        exit()
else:
    if dataset == "Exc3rd":
        outGroup = outGroupSelect("160_trimedBlockExc3rdPhy.txt")
        treeEstimationLine = "raxmlHPC-PTHREADS-SSE3 -f a -x 12345 -p 12345 -# 100 -m GTRCAT -s 160_trimedBlockExc3rdPhy.txt -q 170_raxmlPartition.txt -o " + outGroup + " -n txt -T " + str(num_pthred_raxml)
        outputTree = "200_RAxMLtree_Exc3rd.pdf"
    elif dataset == "Inc3rd":
        outGroup = outGroupSelect("160_trimedBlockInc3rdPhy.txt")
        treeEstimationLine = "raxmlHPC-PTHREADS-SSE3 -f a -x 12345 -p 12345 -# 100 -m GTRCAT -s 160_trimedBlockInc3rdPhy.txt -q 170_raxmlPartition.txt -o " + outGroup + " -n txt -T " + str(num_pthred_raxml)
        outputTree = "200_RAxMLtree_Inc3rd.pdf"
    else:
        outGroup = outGroupSelect("150_trimedAAPhy.txt")
        treeEstimationLine = "raxmlHPC-PTHREADS-SSE3 -f a -x 12345 -p 12345 -# 100 -m PROTCATWAGF -s 150_trimedAAPhy.txt -o " + outGroup + " -n txt -T " + str(num_pthred_raxml)
        outputTree = "200_RAxMLtree_prot.pdf"

#print("treeEstimationLine:", treeEstimationLine)
subprocess.call(treeEstimationLine, shell=True)

if treeSearchMethod == "NJ":
    treePlotR = "Rscript 105_treePlot.R " + "200_NJBStree.txt " + outputTree
else:
    treePlotR = "Rscript 105_treePlot.R " + "RAxML_bipartitions.txt " + outputTree
#print("treePlotR: ", treePlotR)
subprocess.call(treePlotR, shell=True)


remove_files2()


###print("### deleteFiles")


exit()
