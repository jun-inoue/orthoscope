library(ape)
args            <- commandArgs()
Gene_tree       <- args[6]      # treefile
outfileName     <- args[7]

PDF_treeDrawing <- function (tr, prefix)
{
  pdfWidth  <- NULL
  pdfHeight <- NULL
  if (length(tr$tip.label) > 200) {
    pdfWidth  = 28
    pdfHeight = 28
  } else if (length(tr$tip.label) > 100) {
    pdfWidth  = 21
    pdfHeight = 21
  } else if (length(tr$tip.label) > 50) {
    pdfWidth  = 14
    pdfHeight = 14
  } else if (length(tr$tip.label) > 10) {
    pdfWidth  = 15
    pdfHeight = 10
  } else {
    pdfWidth  = 7
    pdfHeight = 7
  }

  pdf(outfileName, width = pdfWidth, height = pdfHeight)
  plot      (tr, no.margin=TRUE, underscore = TRUE, use.edge.length=TRUE, cex = 0.9)
  nodelabels(tr$node.label, adj = c(1.2,-0.5), frame = "n")
  add.scale.bar(cex = 0.9)

  dev.off()
}


Gene_tree <- read.tree(Gene_tree)
Gene_tree <- ladderize(Gene_tree, TRUE)

PDF_treeDrawing(Gene_tree)

