library(ape)
args            <- commandArgs()
pdf.file        <- args[6]
infileName      <- "../000_summary.txt"
Gene_tree       <- "RAxML_bipartitions.txt"

greenPrefixes <- c(); purplePrefixes <- c(); orangePrefixes <- c(); magentaPrefixes <-c(); bluePrefixes <- c()
redPrefixes <- c();

#######
line.picker <- function(keyWord)
{
  container <- c()
  frag <- 0
  lineStock <- c()
  for(line in infile$V1) {
    #print(line)

    ### Collect lines 
    if (regexpr('^>', line) < 0) {
      if(frag == 1) {
        lineStock <- c(lineStock, line)
      }
    }
  
   if (regexpr('^>', line) > 0)
   {
      if(frag == 1)
      {
        container <- c(container, lineStock)
        lineStock <- c()
        break
      }

      #keyWord1 <- paste('>',　keyWord,　sep='')
      if (regexpr(keyWord, line) > 0)
      {
        container <- c(container, line)
        frag <- 1
      }

    }
  }
  container <- c(container, lineStock)    
  container <- container[-1]
  return(container)
}

preab.sub <- function (keyWordA)
{
  #print(keyWordA)
  keyWordA <- paste(keyWordA, "$", sep = "")
  keyWordA <- paste(">", keyWordA, sep = "")
  #print(keyWordA)
  #print("### infile$V1 START ###")
  #print(infile$V1)
  #print("### infile$V1 END ###")
  if(any(i <- grep(keyWordA, infile$V1)))
  {
    #print("Found keyWordA")
    #print(keyWordA)
    #print("")
    containerA <- line.picker(keyWordA)
  } else {
    #print("Not Found keyWordA")
    #print(keyWordA)
    #print("")
    # print (paste('  ',keyWordA,' does not exist.', sep=''))
    containerA  <- NULL
  }
  return(containerA)
}


fontNumChange <- function (tr)
{
  tipFontNums              <- rep(1, length(tr$tip.label))
  #fontNum[queryIDNum]     <- 4
  return (tipFontNums)
}


queryNameInversion <- function (tr, queryNames)
{
  queryTipNums <- c()
  for(i in 1:length(tr$tip.label)){
    for (queryName in queryNames){
      if(regexpr(queryName, tr$tip.label[i]) > 0){
        #print(queryName)
        #print(tr$tip.label[i])
        #print("")
        queryTipNums <- c(queryTipNums, i)
      }
    }
  }
  return(queryTipNums)
}


tipColorChange <- function (tr)
{
  orangeNum <- c(); blueNum <- c(); redNum <- NULL; greenNum <- c(); magentaNum <- c(); purpleNum <- c(); humanNum <- c()

  for(i in 1:length(tr$tip.label)){

    for (redPrefix in redPrefixes){
      if(regexpr(redPrefix, tr$tip.label[i]) > 0){
        redNum <- c(redNum,i)
      }
    }

    for (greenPrefix in greenPrefixes){
      if(regexpr(greenPrefix, tr$tip.label[i]) > 0){
        greenNum <- c(greenNum,i)
      }
    }

    for (purplePrefix in purplePrefixes){
      if(regexpr(purplePrefix, tr$tip.label[i]) > 0){
        purpleNum <- c(purpleNum,i)
      }
    }
  
    for (orangePrefix in orangePrefixes){
      if(regexpr(orangePrefix, tr$tip.label[i]) > 0){
        orangeNum <- c(orangeNum,i)
      }
    }
  
    for (magentaPrefix in magentaPrefixes){
      if(regexpr(magentaPrefix, tr$tip.label[i]) > 0){
        magentaNum <- c(magentaNum,i)
      }
    }  
  
    for (bluePrefix in bluePrefixes){
      #print(bluePrefix)
      if(regexpr(bluePrefix, tr$tip.label[i]) > 0){
        blueNum <- c(blueNum,i)
      }
    }
  
  }

  tipColorNums             <- rep("black",length(tr$tip.label))
  tipColorNums[redNum]     <- "red"
  tipColorNums[greenNum]   <- "darkgreen"
  tipColorNums[purpleNum]  <- "purple"
  tipColorNums[orangeNum]  <- "darkorange1"
  tipColorNums[magentaNum] <- "hotpink2"
  tipColorNums[blueNum]    <- "blue"

  return(tipColorNums)
}

make_colorPrefixes <- function (Species_analysisTMP, colorFN)
{
  colorPrefixes <- c()
  for (line in Species_analysisTMP)
  {
    spPrefixFN <- sub(' +.*$', "", line)   
    if(regexpr(colorFN, line) > 0){
        colorPrefixes <- c(colorPrefixes, spPrefixFN)
    }
  }
  return(colorPrefixes)
}


nodeNameLabel_change <- function (tr)
{
  for(p in 1:length(tr$node.label)){
    #print(tr$node.label[p])
    tr$node.label[p] <- sub('_.*$', "", tr$node.label[p])   
    #print(tr$node.label[p])
  }
  return(tr)
}

edgeWidthChange <- function (tr, OrthoLeaves)
{
  orthoBranchNums <- c()
  for(i in 1:length(tr$tip.label)){
    for(orthoLeaf in OrthoLeaves){
      if (tr$tip.label[i] == orthoLeaf){
        orthoBranchNums <- c(orthoBranchNums, i)
      }
    }
  }

  edgeWidth <- NULL
  if(is.null(orthoBranchNums)){
    edgeWidth          <- rep(1.5, dim(tr$edge)[1])
  } else {
    edgeWidth          <- rep(1.5, dim(tr$edge)[1])
    whOrtho            <- which.edge(tr, orthoBranchNums)
    edgeWidth[whOrtho] <- 4
  }
  return(edgeWidth)
}


PDF_treeDrawing <- function (tr)
{
  pdfWidth  <- NULL
  pdfHeight <- NULL
  if (length(tr$tip.label) > 200) {
    pdfWidth  = 38
    pdfHeight = 28
  } else if (length(tr$tip.label) > 100) {
    pdfWidth  = 31
    pdfHeight = 21
  } else if (length(tr$tip.label) > 50) {
    pdfWidth  = 24
    pdfHeight = 14
  } else if (length(tr$tip.label) > 10) {
    pdfWidth  = 25
    pdfHeight = 10
  } else {
    pdfWidth  = 15
    pdfHeight = 7
  }

  pdf(pdf.file, width = pdfWidth, height = pdfHeight)
  plot      (tr, no.margin=TRUE, underscore = TRUE, use.edge.length=TRUE, cex = 0.9, font = tipFontNums, tip.col = tipColorNums, edge.width = edgeWidth)
  nodelabels(tr$node.label, adj = c(1.2,-0.5), frame = "n")
  if(!is.null(Num_allQueries)){
    tiplabels (tr$tip.label[Num_allQueries], Num_allQueries, cex=1.0, adj = 0, bg = "gray40", col="white")
  }
  if(!is.null(Num_1stQuery)){
    tiplabels (tr$tip.label[Num_1stQuery],   Num_1stQuery, cex=1.0,   adj = 0, bg = "navyblue", col="white")
  }

  dev.off()
}

##################################################################

infile    <- read.table(infileName, na.strings = FALSE, sep = '\t')
Querys_used_in_the_analysis <- preab.sub("Querys_used_in_the_analysis")

Species_analysis_color <- preab.sub("Species_analysis")
greenPrefixes   = make_colorPrefixes(Species_analysis_color, "Green")
purplePrefixes  = make_colorPrefixes(Species_analysis_color, "Purple")
orangePrefixes  = make_colorPrefixes(Species_analysis_color, "Orange")
magentaPrefixes = make_colorPrefixes(Species_analysis_color, "Magenta")
bluePrefixes    = make_colorPrefixes(Species_analysis_color, "Blue")
redPrefixes     = make_colorPrefixes(Species_analysis_color, "Red")

queryNames <- c()
for (line in Querys_used_in_the_analysis)
{
  line <- sub(' +.*$', "", line)   
  queryNames <- c(queryNames, line)
}
Orthogroup             <- preab.sub("Orthogroup")

Rearrangement_BS_value_threshold <- c()
Rearrangement_BS_value_threshold <- preab.sub("Rearrangement_BS_value_threshold")


##################################
Gene_tree <- read.tree(Gene_tree)
Gene_tree <- ladderize(Gene_tree, TRUE)
edgeWidth                    <- edgeWidthChange(Gene_tree, Orthogroup)

tipFontNums                  <- fontNumChange(Gene_tree)
tipColorNums                 <- tipColorChange(Gene_tree)
#nodeLabelFontNums           <- rep(1,length(Gene_tree$tip.label))
#nodeLabelFontSizeNums       <- rep(0.9, length(Gene_tree$tip.label))
Num_allQueries               <- queryNameInversion(Gene_tree, queryNames)
Num_1stQuery                 <- queryNameInversion(Gene_tree, queryNames[1])

PDF_treeDrawing(Gene_tree)

