raxmlHPC-PTHREADS-SSE3 -f a -x 12345 -p 12345 -# 100 -m GTRGAMMA -s 160_trimedBlockExc3rdPhy.txt -q 170_raxmlPartition.txt -o Streptomyces-coelicolor_CAB44539_SCO4554-putative-bi-functi,Streptomyces-coelicolor_CAB72208_SCO2962-putative-bi-functi,Streptomyces-coelicolor_CAB65566_SCO2836-putative-glycosyl- -n txt -T 2


